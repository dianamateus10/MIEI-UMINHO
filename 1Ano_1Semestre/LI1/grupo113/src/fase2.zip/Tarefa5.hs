module Tarefa5 where 

import Types


ghostPlay :: State -> [Play]
ghostPlay x = []
module Tarefa6 where 

import Types


bot :: Int -> State -> Maybe Play
bot x y = Nothing
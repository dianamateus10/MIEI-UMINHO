module Tarefa4 where 

import Types

defaultDelayTime = 250 -- 250 ms

passTime :: Int  -> State -> State
passTime x s = s
